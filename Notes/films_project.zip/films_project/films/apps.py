from django.apps import AppConfig


class FilmsConfig(AppConfig):
    name = 'films'
